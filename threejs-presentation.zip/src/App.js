import React from "react";
import Presentation from "./Pages/Presentation";

import "./App.css";

function App() {
  return <Presentation />;
}

export default App;
